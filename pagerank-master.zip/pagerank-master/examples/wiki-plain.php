<?php

require_once ("../../config.php");

use paslandau\PageRank\Calculation\PageRank;
use paslandau\PageRank\Calculation\ResultFormatter;
use paslandau\PageRank\Edge;
use paslandau\PageRank\Graph;
use paslandau\PageRank\Node;

require_once __DIR__."/bootstrap.php";

$graph = new Graph();

echo "<pre>";
//Categorias filho

include("../../enriquecimento_categoria.php");

$nodes = array();
$dados = json_decode($dados, true);
$i = 0;
foreach ($dados as $key => $value) {
	if (!isset($value["value"])) {
		$value["value"] = $key;
	}
	if (!isset(${$value["value"]})) {
		${$value["value"]} = new Node($value["value"]);
		//$nodes[] = array("name" => $value["value"], "count" => $value["count"]);
		$nodes[] = array("name" => $value["value"]);
	}

	if (isset($value["relacoes"])) {
		foreach ($value["relacoes"] as $keyR => $valueR) {
			if (!isset(${$valueR})) {
				${$valueR} = new Node($valueR);
				//$nodes[] = array("name" => $valueR, "count" => $dados[$valueR]["count"]);
				$nodes[] = array("name" => $valueR);
			}
			$graph->addEdge(new Edge(${$value["value"]},${$valueR}));
		}
	}
	continue;
	$i++;
	if ($i > 300) {
		break;
	}
}

// calculate the PageRank
$pageRank = new PageRank();
$result = $pageRank->calculatePagerank($graph);
$formatter = new ResultFormatter(8);
$resultado = $formatter->getArray($result);

$pageRankArray = array();
foreach ($resultado as $key => $value) {
	if ($key > 0) {
		$pageRankArray[$value[0]] = $value[1];
	}
}

$quartil1Grafo = stats_stat_percentile($pageRankArray, 25);
$quartil3Grafo = stats_stat_percentile($pageRankArray, 75);

/*$quartisSC = array();
foreach ($nodes as $key => $value) {
	if (isset($pageRankArray[$value["name"]])) {
		$quartisSC[] = $value["count"];
	}
}*/

$quartil1SC = stats_stat_percentile($quartisSC, 25);
$quartil3SC = stats_stat_percentile($quartisSC, 75);
$typesRetornados = array();

foreach ($nodes as $key => $value) {
	if (isset($pageRankArray[$value["name"]])) {
		$pg = $pageRankArray[$value["name"]];
	} else {
		$pg = 0;
	}
	//$count = $value["count"];
	if ($pg > $quartil1Grafo && $pg < $quartil3Grafo) {
		//if ($count > $quartil1SC && $count < $quartil3SC) {
			$typesRetornados[] = $value;
		//}
	}
}


echo "<br/>QUARTIS<br/>";
echo ($quartil1Grafo) . '<br/>';
echo ($quartil3Grafo) . '<br/>';
/*
echo ($quartil1SC) . '<br/>';
echo ($quartil3SC) . '<br/>';
*/

var_export($pageRankArray);

echo "<br/><br/>";
var_export("RETORNO<br/>");
//var_export($typesRetornados);
echo "<br/><br/>";

var_export($typesRetornados);
echo "</pre>";