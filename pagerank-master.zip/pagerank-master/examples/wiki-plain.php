<?php

require_once ("../../config.php");

use paslandau\PageRank\Calculation\PageRank;
use paslandau\PageRank\Calculation\ResultFormatter;
use paslandau\PageRank\Edge;
use paslandau\PageRank\Graph;
use paslandau\PageRank\Node;

require_once __DIR__."/bootstrap.php";

$graph = new Graph();

echo "<pre>";
//Categorias filho

//include("../../enriquecimento_categoria_mini.php");
//include("../../enriquecimento_categoria_wikipedia.php");

/*$dados = '{"Animal_viral_diseases":{"value":"Animal_viral_diseases","relacoes":[]},"Healthcare-associated_infections":{"value":"Healthcare-associated_infections","relacoes":[]},"Influenza":{"value":"Influenza","relacoes":[]},"RTT":{"value":"RTT","relacoes":[]},"Dengue_fever":{"value":"Dengue_fever","relacoes":["Animal_viral_diseases"]},"Ebola":{"value":"Ebola","relacoes":["Animal_viral_diseases"]},"Epstein\\u2013Barr_virus-associated_diseases":{"value":"Epstein\\u2013Barr_virus-associated_diseases","relacoes":["Animal_viral_diseases"]},"Papillomavirus-associated_diseases":{"value":"Papillomavirus-associated_diseases","relacoes":["Animal_viral_diseases"]},"Yellow_fever":{"value":"Yellow_fever","relacoes":["Animal_viral_diseases"]},"Viral_respiratory_tract_infections":{"value":"Viral_respiratory_tract_infections","relacoes":["Animal_viral_diseases"]},"Fish_viral_diseases":{"value":"Fish_viral_diseases","relacoes":["Animal_viral_diseases"]},"Arthropod-borne_viral_fevers_and_viral_haemorrhagic_fevers":{"value":"Arthropod-borne_viral_fevers_and_viral_haemorrhagic_fevers","relacoes":["Animal_viral_diseases"]},"Enterovirus-associated_diseases":{"value":"Enterovirus-associated_diseases","relacoes":["Animal_viral_diseases"]},"HIV\\/AIDS":{"value":"HIV\\/AIDS","relacoes":["Animal_viral_diseases"]},"Hemorrhagic_fevers":{"value":"Hemorrhagic_fevers","relacoes":["Animal_viral_diseases"]},"Measles":{"value":"Measles","relacoes":["Animal_viral_diseases"]},"Smallpox":{"value":"Smallpox","relacoes":["Animal_viral_diseases"]},"Varicella_zoster_virus-associated_diseases":{"value":"Varicella_zoster_virus-associated_diseases","relacoes":["Animal_viral_diseases"]},"Viral_infections_of_the_central_nervous_system":{"value":"Viral_infections_of_the_central_nervous_system","relacoes":["Animal_viral_diseases"]},"Virus-related_cutaneous_conditions":{"value":"Virus-related_cutaneous_conditions","relacoes":["Animal_viral_diseases"]},"Cytomegalovirus-associated_diseases":{"value":"Cytomegalovirus-associated_diseases","relacoes":["Animal_viral_diseases"]},"Hepatitis_C_virus-associated_diseases":{"value":"Hepatitis_C_virus-associated_diseases","relacoes":["Animal_viral_diseases"]},"Herpes_simplex_virus-associated_diseases":{"value":"Herpes_simplex_virus-associated_diseases","relacoes":["Animal_viral_diseases"]},"Mumps":{"value":"Mumps","relacoes":["Animal_viral_diseases"]},"Rubella":{"value":"Rubella","relacoes":["Animal_viral_diseases"]},"Chikungunya":{"value":"Chikungunya","relacoes":["Animal_viral_diseases"]},"Hepatitis_A":{"value":"Hepatitis_A","relacoes":["Animal_viral_diseases"]},"Hantavirus_infections":{"value":"Hantavirus_infections","relacoes":["Animal_viral_diseases"]},"Hepatitis_B":{"value":"Hepatitis_B","relacoes":["Animal_viral_diseases"]},"Monkeypox":{"value":"Monkeypox","relacoes":["Animal_viral_diseases"]},"Herpes":{"value":"Herpes","relacoes":["Animal_viral_diseases"]},"Deaths_from_influenza":{"value":"Deaths_from_influenza","relacoes":["Influenza"]},"Influenza_by_country":{"value":"Influenza_by_country","relacoes":["Influenza"]},"Anti-influenza_agents":{"value":"Anti-influenza_agents","relacoes":["Influenza"]},"Avian_influenza":{"value":"Avian_influenza","relacoes":["Influenza"]},"Influenza_researchers":{"value":"Influenza_researchers","relacoes":["Influenza"]},"Influenza_vaccines":{"value":"Influenza_vaccines","relacoes":["Influenza"]},"Influenza_pandemics":{"value":"Influenza_pandemics","relacoes":["Influenza"]},"National_Influenza_Centres":{"value":"National_Influenza_Centres","relacoes":["Influenza"]},"Influenza_A_virus":{"value":"Influenza_A_virus","relacoes":["Influenza"]},"RTT(full)":{"value":"RTT(full)","relacoes":["RTT"]}}';

$dados = '{"Animal_viral_diseases": {"value": "Animal_viral_diseases", "relacoes": [] }, "Healthcare-associated_infections": {"value": "Healthcare-associated_infections", "relacoes": [] }, "Influenza": {"value": "Influenza", "relacoes": [] }, "RTT": {"value": "RTT", "relacoes": [] }, "Dengue_fever": {"value": "Dengue_fever", "relacoes": ["Animal_viral_diseases"] }, "Ebola": {"value": "Ebola", "relacoes": ["Animal_viral_diseases"] }, "Epstein\\u2013Barr_virus-associated_diseases": {"value": "Epstein\\u2013Barr_virus-associated_diseases", "relacoes": ["Animal_viral_diseases"] }, "Papillomavirus-associated_diseases": {"value": "Papillomavirus-associated_diseases", "relacoes": ["Animal_viral_diseases"] }, "Yellow_fever": {"value": "Yellow_fever", "relacoes": ["Animal_viral_diseases"] }, "Viral_respiratory_tract_infections": {"value": "Viral_respiratory_tract_infections", "relacoes": ["Animal_viral_diseases"] }, "Fish_viral_diseases": {"value": "Fish_viral_diseases", "relacoes": ["Animal_viral_diseases"] }, "Arthropod-borne_viral_fevers_and_viral_haemorrhagic_fevers": {"value": "Arthropod-borne_viral_fevers_and_viral_haemorrhagic_fevers", "relacoes": ["Animal_viral_diseases"] }, "Enterovirus-associated_diseases": {"value": "Enterovirus-associated_diseases", "relacoes": ["Animal_viral_diseases"] }, "HIV\\/AIDS": {"value": "HIV\\/AIDS", "relacoes": ["Animal_viral_diseases"] }, "Hemorrhagic_fevers": {"value": "Hemorrhagic_fevers", "relacoes": ["Animal_viral_diseases"] }, "Measles": {"value": "Measles", "relacoes": ["Animal_viral_diseases"] }, "Smallpox": {"value": "Smallpox", "relacoes": ["Animal_viral_diseases"] }, "Varicella_zoster_virus-associated_diseases": {"value": "Varicella_zoster_virus-associated_diseases", "relacoes": ["Animal_viral_diseases"] }, "Viral_infections_of_the_central_nervous_system": {"value": "Viral_infections_of_the_central_nervous_system", "relacoes": ["Animal_viral_diseases"] }, "Virus-related_cutaneous_conditions": {"value": "Virus-related_cutaneous_conditions", "relacoes": ["Animal_viral_diseases"] }, "Cytomegalovirus-associated_diseases": {"value": "Cytomegalovirus-associated_diseases", "relacoes": ["Animal_viral_diseases"] }, "Hepatitis_C_virus-associated_diseases": {"value": "Hepatitis_C_virus-associated_diseases", "relacoes": ["Animal_viral_diseases"] }, "Herpes_simplex_virus-associated_diseases": {"value": "Herpes_simplex_virus-associated_diseases", "relacoes": ["Animal_viral_diseases"] }, "Mumps": {"value": "Mumps", "relacoes": ["Animal_viral_diseases"] }, "Rubella": {"value": "Rubella", "relacoes": ["Animal_viral_diseases"] }, "Chikungunya": {"value": "Chikungunya", "relacoes": ["Animal_viral_diseases"] }, "Hepatitis_A": {"value": "Hepatitis_A", "relacoes": ["Animal_viral_diseases"] }, "Hantavirus_infections": {"value": "Hantavirus_infections", "relacoes": ["Animal_viral_diseases"] }, "Hepatitis_B": {"value": "Hepatitis_B", "relacoes": ["Animal_viral_diseases"] }, "Monkeypox": {"value": "Monkeypox", "relacoes": ["Animal_viral_diseases"] }, "Herpes": {"value": "Herpes", "relacoes": ["Animal_viral_diseases"] }, "Deaths_from_influenza": {"value": "Deaths_from_influenza", "relacoes": ["Influenza"] }, "Influenza_by_country": {"value": "Influenza_by_country", "relacoes": ["Influenza"] }, "Anti-influenza_agents": {"value": "Anti-influenza_agents", "relacoes": ["Influenza"] }, "Avian_influenza": {"value": "Avian_influenza", "relacoes": ["Influenza"] }, "Influenza_researchers": {"value": "Influenza_researchers", "relacoes": ["Influenza"] }, "Influenza_vaccines": {"value": "Influenza_vaccines", "relacoes": ["Influenza"] }, "Influenza_pandemics": {"value": "Influenza_pandemics", "relacoes": ["Influenza"] }, "National_Influenza_Centres": {"value": "National_Influenza_Centres", "relacoes": ["Influenza"] }, "Influenza_A_virus": {"value": "Influenza_A_virus", "relacoes": ["Influenza"] }, "RTT(full)": {"value": "RTT(full)", "relacoes": ["RTT"] }, "MARCOS": {"value": "MARCOS", "relacoes": ["Augusto"] }, "Augusto": {"value": "Augusto", "relacoes": []}}';

$dados = '{"1999 establishments in Switzerland":{"value":"1999 establishments in Switzerland","relacoes":[]},"1999 Swiss television series debuts":{"value":"1999 Swiss television series debuts","relacoes":["1999 establishments in Switzerland"]},"European newspaper stubs":{"value":"European newspaper stubs","relacoes":[]},"Albanian newspaper stubs":{"value":"Albanian newspaper stubs","relacoes":["European newspaper stubs"]},"French newspaper stubs":{"value":"French newspaper stubs","relacoes":["European newspaper stubs"]},"German newspaper stubs":{"value":"German newspaper stubs","relacoes":["European newspaper stubs"]},"Irish newspaper stubs":{"value":"Irish newspaper stubs","relacoes":["European newspaper stubs"]},"Italian newspaper stubs":{"value":"Italian newspaper stubs","relacoes":["European newspaper stubs"]},"Norwegian newspaper stubs":{"value":"Norwegian newspaper stubs","relacoes":["European newspaper stubs"]},"Polish newspaper stubs":{"value":"Polish newspaper stubs","relacoes":["European newspaper stubs"]},"Romanian newspaper stubs":{"value":"Romanian newspaper stubs","relacoes":["European newspaper stubs"]},"Russian newspaper stubs":{"value":"Russian newspaper stubs","relacoes":["European newspaper stubs"]},"United Kingdom newspaper stubs":{"value":"United Kingdom newspaper stubs","relacoes":["European newspaper stubs"]},"Free daily newspapers":{"value":"Free daily newspapers","relacoes":[]},"Defunct free daily newspapers":{"value":"Defunct free daily newspapers","relacoes":["Free daily newspapers"]},"German-language newspapers published in Switzerland":{"value":"German-language newspapers published in Switzerland","relacoes":[]},"Publications established in 1999":{"value":"Publications established in 1999","relacoes":[]},"1999 comics debuts":{"value":"1999 comics debuts","relacoes":["Publications established in 1999"]},"Magazines established in 1999":{"value":"Magazines established in 1999","relacoes":["Publications established in 1999"]},"Swiss media stubs":{"value":"Swiss media stubs","relacoes":[]},"Swiss film stubs":{"value":"Swiss film stubs","relacoes":["Swiss media stubs"]},"Audio storage":{"value":"Audio storage","relacoes":[]},"Digital audio storage":{"value":"Digital audio storage","relacoes":["Audio storage"]},"Record collecting":{"value":"Record collecting","relacoes":["Audio storage"]},"Singles (music)":{"value":"Singles (music)","relacoes":["Audio storage"]},"Tape recording":{"value":"Tape recording","relacoes":["Audio storage"]},"Music industry":{"value":"Music industry","relacoes":[]},"Audio branding":{"value":"Audio branding","relacoes":["Music industry"]},"Audio equipment manufacturers":{"value":"Audio equipment manufacturers","relacoes":["Music industry"]},"Commissioned music":{"value":"Commissioned music","relacoes":["Music industry"]},"DJing":{"value":"DJing","relacoes":["Music industry"]},"Free music":{"value":"Free music","relacoes":["Music industry"]},"Music awards":{"value":"Music awards","relacoes":["Music industry"]},"Music companies":{"value":"Music companies","relacoes":["Music industry"]},"Music conferences":{"value":"Music conferences","relacoes":["Music industry"]},"Music industries by country":{"value":"Music industries by country","relacoes":["Music industry"]},"Music industry executives":{"value":"Music industry executives","relacoes":["Music industry"]},"1849 establishments in Finland":{"value":"1849 establishments in Finland","relacoes":["1849 establishments in Russia"]},"1849 establishments in Russia":{"value":"1849 establishments in Russia","relacoes":[]}}';
*/

//Nas relacoes constam os idsPais

echo "<pre>";

//$dados = '{"1999 establishments in Switzerland":{"value":"1999 establishments in Switzerland","relacoes":[]},"1999 Swiss television series debuts":{"value":"1999 Swiss television series debuts","relacoes":["1999 establishments in Switzerland"]},"European newspaper stubs":{"value":"European newspaper stubs","relacoes":[]},"Albanian newspaper stubs":{"value":"Albanian newspaper stubs","relacoes":["European newspaper stubs"]},"French newspaper stubs":{"value":"French newspaper stubs","relacoes":["European newspaper stubs"]},"German newspaper stubs":{"value":"German newspaper stubs","relacoes":["European newspaper stubs"]},"Irish newspaper stubs":{"value":"Irish newspaper stubs","relacoes":["European newspaper stubs"]},"Italian newspaper stubs":{"value":"Italian newspaper stubs","relacoes":["European newspaper stubs"]},"Norwegian newspaper stubs":{"value":"Norwegian newspaper stubs","relacoes":["European newspaper stubs"]},"Polish newspaper stubs":{"value":"Polish newspaper stubs","relacoes":["European newspaper stubs"]},"Romanian newspaper stubs":{"value":"Romanian newspaper stubs","relacoes":["European newspaper stubs"]},"Russian newspaper stubs":{"value":"Russian newspaper stubs","relacoes":["European newspaper stubs"]},"United Kingdom newspaper stubs":{"value":"United Kingdom newspaper stubs","relacoes":["European newspaper stubs"]},"Free daily newspapers":{"value":"Free daily newspapers","relacoes":[]},"Defunct free daily newspapers":{"value":"Defunct free daily newspapers","relacoes":["Free daily newspapers"]},"German-language newspapers published in Switzerland":{"value":"German-language newspapers published in Switzerland","relacoes":[]},"Publications established in 1999":{"value":"Publications established in 1999","relacoes":[]},"1999 comics debuts":{"value":"1999 comics debuts","relacoes":["Publications established in 1999"]},"Magazines established in 1999":{"value":"Magazines established in 1999","relacoes":["Publications established in 1999"]}}';


include("../../pagerank.include.php");

$nodes = array();
$dados = json_decode($dados, true);
$i = 0;
foreach ($dados as $key => $value) {
	if (!isset($value["value"])) {
		$value["value"] = $key;
	}
	if (!isset(${$value["value"]})) {
		${$value["value"]} = new Node($value["value"]);
		//$nodes[] = array("name" => $value["value"], "count" => $value["count"]);
		$nodes[] = array("name" => $value["value"]);
	}

	if (isset($value["relacoes"]) && count($value["relacoes"])) {
		foreach ($value["relacoes"] as $keyR => $valueR) {
			if (!isset(${$valueR})) {
				${$valueR} = new Node($valueR);
				//$nodes[] = array("name" => $valueR, "count" => $dados[$valueR]["count"]);
				$nodes[] = array("name" => $valueR);
			}

			var_export("Bridge " . $value["value"] .  " - >  " . $valueR . "<br/>");
			$graph->addEdge(new Edge(${$value["value"]},${$valueR}));
		}
	}
	continue;
	$i++;
	if ($i > 300) {
		break;
	}
}

//die;

// calculate the PageRank
$pageRank = new PageRank();
$result = $pageRank->calculatePagerank($graph);
$formatter = new ResultFormatter(8);
$resultado = $formatter->getArray($result);

$pageRankArray = array();
foreach ($resultado as $key => $value) {
	if ($key > 0) {
		$pageRankArray[$value[0]] = $value[1];
	}
}

//var_export($pageRankArray);

$quartil1Grafo = stats_stat_percentile($pageRankArray, 25);
$quartil3Grafo = stats_stat_percentile($pageRankArray, 75);

/*$quartisSC = array();
foreach ($nodes as $key => $value) {
	if (isset($pageRankArray[$value["name"]])) {
		$quartisSC[] = $value["count"];
	}
}*/

$quartil1SC = stats_stat_percentile($quartisSC, 25);
$quartil3SC = stats_stat_percentile($quartisSC, 75);
$typesRetornados = array();

foreach ($nodes as $key => $value) {
	if (isset($pageRankArray[$value["name"]])) {
		$pg = $pageRankArray[$value["name"]];
	} else {
		$pg = 0;
	}
	//$count = $value["count"];
	if ($pg > $quartil1Grafo && $pg < $quartil3Grafo) {
		//if ($count > $quartil1SC && $count < $quartil3SC) {
			$typesRetornados[] = $value;
		//}
	}
}


echo "<br/>QUARTIS<br/>";
echo ($quartil1Grafo) . '<br/>';
echo ($quartil3Grafo) . '<br/>';
/*
echo ($quartil1SC) . '<br/>';
echo ($quartil3SC) . '<br/>';
*/

var_export($pageRankArray);

echo "<br/><br/>";
var_export("RETORNO<br/>");
//var_export($typesRetornados);
echo "<br/><br/>";

var_export($typesRetornados);
echo "</pre>";