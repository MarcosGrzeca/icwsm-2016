#todo
- ! add readme
- ! handle empty nodes/columns on CSV import (e.g. when a node should be inlcuded but has no link pointing to/from it)
- ! test disconnected graphs
- ! add more fine-grained tests (e.g. for a single round of calculation)
- implement weighted links
- take nofollow links into account
- deal with dangling links (remove / resolve optionally)
- implement random walker / reasonable walker

#dev-master

- initial commit